import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class GasServiceFee extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			GasServiceFee dialog = new GasServiceFee();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public GasServiceFee() {
		setBounds(100, 100, 490, 201);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Enter the total number of gallons used, divided by 1000");
			lblNewLabel.setBounds(10, 11, 328, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			textField = new JTextField();
			textField.setBounds(348, 8, 86, 20);
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JTextPane textPane = new JTextPane();
			textPane.setBounds(117, 50, 41, 20);
			contentPanel.add(textPane);
		}
		{
			JLabel lblYouHaveUsed = new JLabel("You have used");
			lblYouHaveUsed.setBounds(10, 56, 97, 14);
			contentPanel.add(lblYouHaveUsed);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("thousand gallons of water.");
			lblNewLabel_1.setBounds(184, 56, 162, 14);
			contentPanel.add(lblNewLabel_1);
		}
		{
			JLabel lblYourTotalWater = new JLabel("Your total water bill is");
			lblYourTotalWater.setBounds(10, 106, 131, 14);
			contentPanel.add(lblYourTotalWater);
		}
		{
			JTextPane textPane = new JTextPane();
			textPane.setBounds(149, 100, 41, 20);
			contentPanel.add(textPane);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
