import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JInternalFrame;
import javax.swing.JTextPane;

public class QueryService extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			QueryService dialog = new QueryService();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public QueryService() {
		setBounds(100, 100, 357, 276);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Please Enter The Service Number");
			lblNewLabel.setBounds(10, 11, 281, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			textField = new JTextField();
			textField.setBounds(223, 8, 86, 20);
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 36, 414, 170);
		contentPanel.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Service Number");
		lblNewLabel_1.setBounds(24, 24, 156, 14);
		panel.add(lblNewLabel_1);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(190, 18, 114, 20);
		panel.add(textPane);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(24, 61, 121, 14);
		panel.add(lblName);
		
		JTextPane textPane_1 = new JTextPane();
		textPane_1.setBounds(190, 55, 114, 20);
		panel.add(textPane_1);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setBounds(24, 98, 104, 14);
		panel.add(lblPrice);
		
		JTextPane textPane_1_1 = new JTextPane();
		textPane_1_1.setBounds(190, 92, 114, 20);
		panel.add(textPane_1_1);
		
		JLabel lblDiscount = new JLabel("Discount %");
		lblDiscount.setBounds(24, 134, 104, 14);
		panel.add(lblDiscount);
		
		JTextPane textPane_1_1_1 = new JTextPane();
		textPane_1_1_1.setBounds(190, 128, 114, 20);
		panel.add(textPane_1_1_1);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
