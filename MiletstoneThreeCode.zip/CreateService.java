import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class CreateService extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			CreateService dialog = new CreateService();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public CreateService() {
		setBounds(100, 100, 401, 189);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblPleaseEnterThe = new JLabel("Please Enter The Service Number");
			lblPleaseEnterThe.setBounds(10, 11, 245, 14);
			contentPanel.add(lblPleaseEnterThe);
		}
		{
			textField = new JTextField();
			textField.setBounds(265, 8, 86, 20);
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JLabel lblPleaseEnterThe_1 = new JLabel("Please Enter The Name of The Service");
			lblPleaseEnterThe_1.setBounds(10, 36, 245, 14);
			contentPanel.add(lblPleaseEnterThe_1);
		}
		{
			textField_1 = new JTextField();
			textField_1.setBounds(265, 33, 86, 20);
			contentPanel.add(textField_1);
			textField_1.setColumns(10);
		}
		{
			JLabel lblPleaseEnterThe_2 = new JLabel("Please Enter The Price of The Service");
			lblPleaseEnterThe_2.setBounds(10, 61, 245, 14);
			contentPanel.add(lblPleaseEnterThe_2);
		}
		{
			textField_2 = new JTextField();
			textField_2.setBounds(265, 58, 86, 20);
			contentPanel.add(textField_2);
			textField_2.setColumns(10);
		}
		{
			JLabel lblPleaseEnterThe_3 = new JLabel("Please Enter The Discount (%)");
			lblPleaseEnterThe_3.setBounds(10, 86, 245, 14);
			contentPanel.add(lblPleaseEnterThe_3);
		}
		{
			textField_3 = new JTextField();
			textField_3.setBounds(265, 83, 86, 20);
			contentPanel.add(textField_3);
			textField_3.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

}
