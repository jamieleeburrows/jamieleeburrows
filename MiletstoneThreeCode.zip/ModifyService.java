import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ModifyService extends JDialog {
	private JTable table;

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ModifyService dialog = new ModifyService();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public ModifyService() {
		setBounds(100, 100, 450, 387);
		getContentPane().setLayout(null);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBounds(0, 314, 434, 33);
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		{
			{
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				scrollPane.setBounds(0, 62, 434, 123);
				getContentPane().add(scrollPane);
				table = new JTable();
				scrollPane.setViewportView(table);
				table.setRowSelectionAllowed(false);
				table.setModel(new DefaultTableModel(
					new Object[][] {
						{null, null, null, null},
						{null, null, null, null},
						{null, null, null, null},
						{null, null, null, null},
						{null, null, null, null},
						{null, null, null, null},
					},
					new String[] {
						"Service Number", "Name", "Price", "Discount %"
					}
				) {
					Class[] columnTypes = new Class[] {
						Integer.class, String.class, Double.class, Double.class
					};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
				});
				{
					JLabel lblPleaseEnterThe = new JLabel("Please Enter The Service Number of The Service");
					lblPleaseEnterThe.setBounds(10, 11, 282, 14);
					getContentPane().add(lblPleaseEnterThe);
				}
				{
					textField = new JTextField();
					textField.setBounds(306, 8, 86, 20);
					getContentPane().add(textField);
					textField.setColumns(10);
				}
				{
					JLabel lblPleaseEnterThe = new JLabel("Please Enter The Service Number");
					lblPleaseEnterThe.setBounds(34, 214, 245, 14);
					getContentPane().add(lblPleaseEnterThe);
				}
				{
					textField_1 = new JTextField();
					textField_1.setColumns(10);
					textField_1.setBounds(289, 211, 86, 20);
					getContentPane().add(textField_1);
				}
				{
					JLabel lblPleaseEnterThe_1 = new JLabel("Please Enter The Name of The Service");
					lblPleaseEnterThe_1.setBounds(34, 239, 245, 14);
					getContentPane().add(lblPleaseEnterThe_1);
				}
				{
					textField_2 = new JTextField();
					textField_2.setColumns(10);
					textField_2.setBounds(289, 236, 86, 20);
					getContentPane().add(textField_2);
				}
				{
					JLabel lblPleaseEnterThe_2 = new JLabel("Please Enter The Price of The Service");
					lblPleaseEnterThe_2.setBounds(34, 264, 245, 14);
					getContentPane().add(lblPleaseEnterThe_2);
				}
				{
					textField_3 = new JTextField();
					textField_3.setColumns(10);
					textField_3.setBounds(289, 261, 86, 20);
					getContentPane().add(textField_3);
				}
				{
					JLabel lblPleaseEnterThe_3 = new JLabel("Please Enter The Discount (%)");
					lblPleaseEnterThe_3.setBounds(34, 289, 245, 14);
					getContentPane().add(lblPleaseEnterThe_3);
				}
				{
					textField_4 = new JTextField();
					textField_4.setColumns(10);
					textField_4.setBounds(289, 286, 86, 20);
					getContentPane().add(textField_4);
				}
				table.getColumnModel().getColumn(0).setPreferredWidth(97);
			}
		}
	}
}
