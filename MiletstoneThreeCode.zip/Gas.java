/*
 * Gas.java
 *
 */

import java.util.Scanner;

public class Gas
{
	
	//***************************************************************
	//    	Constructor/Descructor
	//****************************************************************

	public Gas()
	{
		

	}

	public void dispose()
	{
		
	}
	

	//***************************************************************
	//    	GAS FEE CALCULATION
	//****************************************************************

	public final int gasChargeCalc(int a, int b)
	{
		int sum;
		sum = a + b;
		return sum;

	}
	public final double gasChargeCalc(int a, double b)
	{
		double sum;
		sum = Double.valueOf(a) + b;
		return sum;
	}

	public final void gasFeeCalculation()
	{

		double gallons;
		double charge = 0;
		double total;
		final int fee = 15;
		double costUpTo6K = 2.35;
		double costUpTo20K = 3.75;
		double costOver20K = 6.00;
		Scanner scanner = new Scanner(System.in);

	   	System.out.print("\n\n\n\tEnter the total number of gallons used, divided by 1000: ");
		gallons = scanner.nextDouble();

		if (gallons > 20)
		{
			charge = (gallons - 20) * costOver20K;
			charge = charge + (14 * costUpTo20K);
			charge = charge + (6 * costUpTo6K);
		}
		else if (gallons > 6 && gallons <= 20)
		{

			charge = (gallons - 6) * costUpTo20K;
			charge = charge + (6 * costUpTo6K);
		}
		else
		{

			charge = gallons * costUpTo6K;
		}

		total = gasChargeCalc(fee, charge);
		System.out.print("\n\n\n\tYou have used ");
		System.out.print(gallons);
		System.out.print(" thousand gallons of water.");
		System.out.print("\n");
		System.out.print("\n\n\n\tYour total water bill is $");
		System.out.printf("%.2f", total);
	}

}