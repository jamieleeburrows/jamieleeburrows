/*
 * Final_Utility_Company_System.java
 *
 */


import java.util.Scanner;

public class Final_Utility_Company_System
{
	
    //Global variables

	public static Service[] serv = new Service[50];

    public static int counter = 0;

	public static Gas gasInfo = new Gas();
	
	public static Scanner scanner = new Scanner(System.in);

	//***************************************************************
	//    	Main program
	//****************************************************************

	public static void main(String[] args)
	{
	    int ch;
	   

		do
		{
			System.out.print("\n\n\n\tMAIN MENU");
			System.out.print("\n\n\t01. CUSTOMER");
			System.out.print("\n\n\t02. ADMINISTRATOR");
			System.out.print("\n\n\t03. EXIT");
			System.out.print("\n\n\tPlease Select Your Option (1-3) ");
			ch = scanner.nextInt();

			switch (ch)
			{
				case 1:
					placeOrder();
					scanner.nextLine();
					break;
				case 2:
					adminMenu();
					break;
				case 3:
					System.exit(0);
				default :
					System.out.print("\n");
			}
		}while (ch != 3);
    }
	
    
    //***************************************************************
	//    	ADMINSTRATOR MENU FUNCTION
	//****************************************************************

	public static void adminMenu()
	{
		int ch2;
		
		System.out.print("\n\n\n\tADMIN MENU");
		System.out.print("\n\n\t1.CREATE SERVICE");
		System.out.print("\n\n\t2.DISPLAY ALL SERVICES");
		System.out.print("\n\n\t3.QUERY ");
		System.out.print("\n\n\t4.GAS SERVICE FEE ");
		System.out.print("\n\n\t5.MODIFY SERVICE");
		System.out.print("\n\n\t6.DELETE SERVICE");
		System.out.print("\n\n\t7.VIEW SERVICE MENU");
		System.out.print("\n\n\t8.BACK TO MAIN MENU");
		System.out.print("\n\n\tPlease Enter Your Choice (1-8) ");
		ch2 = scanner.nextInt();

		switch (ch2)
		{
		case 1:
			createService();
			scanner.nextLine();
			break;
		case 2:
			displayAll();
			break;
		case 3:
			int num;
			System.out.print("\n\n\tPlease Enter The Service Number ");
			num = scanner.nextInt();
			displayService(num);
			break;
		case 4:
			gasInfo.gasFeeCalculation();
			break;
		case 5:
			modifyService();
			break;
		case 6:
			deleteService();
			break;
		case 7:
			serviceMenu();
			scanner.nextLine();
		case 8:
			break;
		default:
			System.out.print("\n");
			adminMenu();
		}
    }

    //***************************************************************
	//    	Modify Service MENU FUNCTION
	//****************************************************************	

	public static void modifyService()
	{
		int no;
        int found = 0;
        int loop = 0;

		serviceMenu();
		System.out.print("\n\nTo Modify ");
		System.out.print("\n\nPlease Enter The Service Number of The Service:\n");
		no = scanner.nextInt();

		while (loop<counter  && found == 0)
		{
			if (serv[loop].retsno() == no)
			{
				serv[loop].showService();
				System.out.print("\nPlease Enter The New Details of Service");
				System.out.print("\n");
				createService(); 

				System.out.print("\n\n\t Record Updated");
				found = 1;
            }
            loop++;
		}
	
		if (found == 0)
		{
			System.out.print("\n\n Record Not Found ");
		}
		scanner.nextLine();
	}
	
    //***************************************************************
	//    	Create Service MENU FUNCTION
	//****************************************************************	

	public static void createService()
	{
		int customer_number;
		String name = new String(new char[50]);
		float serviceVar;
		float discount;
		
		System.out.print("Please Enter The Service Number:\n");
		customer_number = scanner.nextInt();

		System.out.print("Please Enter The Name of The Service:\n");
		name = scanner.next();

		System.out.print("Please Enter The Price of The Service:\n");
		serviceVar = scanner.nextFloat();

		System.out.print("Please Enter The Discount (%):\n");
		discount = scanner.nextFloat();
		
		serv[counter] = new Service(customer_number, name, serviceVar, discount);
		counter++;
		
		displayService(customer_number);
	}
	
	//***************************************************************
    //    	function to place order and generating bill for Services
    //****************************************************************
	public static void placeOrder()
	{
		int[] order_arr = new int[50];
		int[] quan = new int[50];
		int c = 0;
		float amt;
		float damt;
		float total = 0F;
        String ch = "Y";
        int loop = 0;

		serviceMenu();
		System.out.print("\n============================");
		System.out.print("\n    PLACE YOUR ORDER");
		System.out.print("\n============================\n");

		do
		{
			System.out.print("\n\nEnter The Service Number Of The Service : ");
			order_arr[c] = scanner.nextInt();

			System.out.print("\nQuantity in number : ");
			quan[c] = scanner.nextInt();

			c++;

			System.out.print("\nDo You Want To Order Another Service ? (y/n)");
			ch = scanner.next();
		}while (ch == "y" || ch == "Y");

		System.out.print("\n\nThank You For Placing The Order");
		
		System.out.print("\n\n********************************INVOICE************************\n");
		System.out.print("\nPr Number\tPr Name\tQuantity \tPrice \tAmount \tAmount after discount\n");
		for (int x = 0;x <= c;x++)
		{
			loop = 0;
			while (loop < counter )
			{
				if (serv[loop].retsno() == order_arr[x])
				{
					amt = serv[loop].retService() * quan[x];
					damt = amt - (amt * serv[loop].retdis() / 100);
					System.out.print("\n");
					System.out.print(order_arr[x]);
					System.out.print("\t");
					System.out.print(serv[loop].retname());
					System.out.print("\t");
					System.out.print(quan[x]);
					System.out.print("\t\t");
					System.out.print(serv[loop].retService());
					System.out.print("\t");
					System.out.print(amt);
					System.out.print("\t\t");
					System.out.print(damt);
					total += damt;
                }
                loop++;

			}
			
		}

		System.out.print("\n\n\t\t\t\t\tTOTAL = ");
		System.out.print(total);
    }

    //***************************************************************
	//    	Displays all services
	//****************************************************************

	public static void displayAll()
	{
       int loop = 0;
       
	   System.out.print("\n\n\n\t\tDISPLAY ALL RECORD !!!\n\n");

	   while (loop < counter )
	   {
			serv[loop].showService();
			System.out.print("\n\n====================================\n");
			loop++;
	   }
    }
    
	//***************************************************************
	//    	Displays specified service
	//****************************************************************
	
	public static void displayService(int n)
	{
        int flag = 0;
        int loop = 0;
		
		while ( loop<counter)
		{
		 if (serv[loop].retsno() == n)
		 {
			serv[loop].showService();
			flag = 1;
         }
         loop++;
		}
	
		if (flag == 0)
		{
			System.out.print("\n\nrecord not exist");
		}
    }
    
    //***************************************************************
	//    	function to display all Services Service list
	//****************************************************************

	public static void serviceMenu()
	{
        int loop = 0;
		 
		System.out.print("\n\n\t\tService MENU\n\n");
		System.out.print("====================================================\n");
		System.out.print("P.NO.\t\tNAME\t\tPRICE\n");
		System.out.print("====================================================\n");


		while ( loop<counter)
		{
			System.out.print(serv[loop].retsno());
			System.out.print("\t\t");
			System.out.print(serv[loop].retname());
			System.out.print("\t\t");
			System.out.print(serv[loop].retService());
			System.out.print("\n");
			loop++;
		}
		 
	}
    
    //***************************************************************
	//    	function to delete a service 
	//****************************************************************

	public static void deleteService()
	{
        int no;
        int loop = 0;

		System.out.print("\n\n\n\tDelete Record");
		System.out.print("\n\nPlease Enter The Service no. of The Service You Want To Delete");
		no = scanner.nextInt();
		
		while (loop<counter )
		{
			if (serv[loop].retsno() == no)
			{
				while (loop<counter )
				{
					serv[loop] = serv[loop+1];
					loop++;
				}
				counter--;
			}
			loop++;
		}
		
		System.out.print("\n\n\tRecord Deleted ..");
	}
		
}