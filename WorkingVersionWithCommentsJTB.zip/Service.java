/*
 * Service.java
 *
 */

import java.util.Scanner;

public class Service
{
	// Variable declarations
	
	public int customer_number;
	public String name = new String(new char[50]);
	public float serviceVar;
	public float discount;

	Scanner scanner = new Scanner(System.in);

	//***************************************************************
	//    	Constructor/Descructor
	//****************************************************************
	
	Service(int customer_number, String name, float serviceVar, float discount)
	{
		this.customer_number = customer_number;
		this.name = name;
		this.serviceVar = serviceVar;
		this.discount = discount;
	}

	public void dispose()
	{
		
	}

	//***************************************************************
	//    	Displays the service details
	//****************************************************************

	public final void showService()
	{
		 System.out.print("\nThe Service Number : ");
		 System.out.print(customer_number);

		 System.out.print("\nThe Name of The Service : ");
		 System.out.println(name);

		 System.out.print("\nThe Price of The Service : ");
		 System.out.print(serviceVar);

		 System.out.print("\nDiscount : ");
		 System.out.print(discount);
	}

	//***************************************************************
	//    	data request functions
	//****************************************************************

	public final int retsno()
	{
		return customer_number;
	}

	public final float retService()
	{
		return serviceVar;
	}

	public final String retname()
	{
		return name;
	}

	public final float retdis()
	{
		return discount;
	}
}